#!/usr/bin/env python3
import sys
for line in sys.stdin:
    line = line.strip()
    parts = line.split(',')
    if line.startswith("X"):  # Skip header
        continue
    month = parts[2]
    temp = parts[8]
    print(f"{month}\t{temp}")
