#!/usr/bin/env python3
import sys
from collections import defaultdict

current_month = None
total_temp = 0
count = 0

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    month, temp = line.split('\t')
    temp = float(temp)
    
    if current_month == month:
        total_temp += temp
        count += 1
    else:
        if current_month:
            avg = total_temp / count
            print(f"{current_month}\t{avg:.2f}")
        current_month = month
        total_temp = temp
        count = 1

# Final
if current_month:
    avg = total_temp / count
    print(f"{current_month}\t{avg:.2f}")
